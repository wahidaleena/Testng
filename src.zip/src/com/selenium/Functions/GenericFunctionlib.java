package com.selenium.Functions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;
import com.selenium.pof.PageFactoryDefinition;

public class GenericFunctionlib extends Testbase{
	
	
	public static void openBrowser(String url) throws IOException
	{
		
	   if(browser.equals("ie"))
		{
		System.setProperty("webdriver.ie.driver", "C:\\Users\\u60903\\Downloads\\IEdriver\\IEDriverServer.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		  
		capabilities.setCapability(CapabilityType.BROWSER_NAME, "IE");
		capabilities.setCapability(InternetExplorerDriver.
		  INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		driver=new InternetExplorerDriver(capabilities);
		wait = new WebDriverWait(driver,400);
		driver.get(url);
		
		}
		else if(browser.equals("chrome"))
		{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\u60903\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		wait = new WebDriverWait(driver,300);
		System.out.println(url);
		driver.get(url);
		
		}
		else
			System.out.println("Sorry,No such browser exist!");
		
		
		
	}
	public static void closeBrowser()
	{
		driver.close();
	}
	
}
