package com.selenium.Functions;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

//import org.testng.Assert;

import com.selenium.base.Testbase;
import com.selenium.pof.PageFactoryDefinition;
import com.selenium.pom.Cart;

import com.selenium.pom.IAgree;

import com.selenium.pom.Registration;
import com.selenium.pom.Search;
import com.selenium.pom.Signin;
import com.selenium.pom.Username;

public class LegacyFunctions extends Testbase {
	
	public static void searchItem(String data) {
		if(browser.equals("chrome"))
		{
		//IAgree.agree(driver, wait).click();
			String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,Keys.RETURN); 
	        driver.findElement(By.name("button")).sendKeys(selectLinkOpeninNewTab);
	        
	        ArrayList<String> handle= new ArrayList<String>(driver.getWindowHandles());//Return a string of alphanumeric window handle
	 
	 
	        driver.switchTo().window(handle.get(1)); 
		Search.search(driver, wait).sendKeys(data);
		 Assert.assertEquals(Search.search(driver,
		 wait).getAttribute("value"), data);
		Search.submit(driver, wait).click();
		}
		else
		{
		Search.search(driver, wait).sendKeys(data);
		 Assert.assertEquals(Search.search(driver,
		 wait).getAttribute("value"), data);
		Search.submit(driver, wait).click();
		}

	}

	public static  void sign() {
		PageFactoryDefinition page=PageFactory.initElements(driver,PageFactoryDefinition.class);
		if(browser.equals("chrome"))
		{
		//IAgree.agree(driver, wait).click();
			//WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.name("button")));
			page.agree.click();
		}
		//Signin.signin(driver, wait).click();
		//WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.name("login")));
		page.login.click();
		System.out.println("The current webelement is"+element);
	}

	public static void reg(String email, String pass, String fname, String lname, String cpmny, String addr1,
			String addr2, String city, String state, String post, String home, String phone) 
	{
		PageFactoryDefinition page=PageFactory.initElements(driver,PageFactoryDefinition.class);
		String mail = email + System.currentTimeMillis() + "@yahoo.com";
		System.out.println(mail);
		//Username.signin(driver, wait).sendKeys(mail);
		//WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email_create")));
		System.out.println("The mail id is"+mail);
		PageFactoryDefinition.email.sendKeys(mail);
		 /*Assert.assertEquals(Username.signin(driver,
		wait).getAttribute("value"), mail);*/
		//Username.create(driver, wait).click();
		 PageFactoryDefinition.create.click();
        //Registration.first(driver, wait).sendKeys(fname);
		 PageFactoryDefinition.first.sendKeys(fname);
        System.out.println(fname);
		Assert.assertEquals(Registration.first(driver,
		 wait).getAttribute("value"), fname);
		//Registration.second(driver, wait).sendKeys(lname);
		PageFactoryDefinition.last.sendKeys(lname);
		System.out.println(lname);
		//Registration.company(driver, wait).sendKeys(cpmny);
		PageFactoryDefinition.company.sendKeys(cpmny);
		System.out.println(cpmny);
		//Registration.password(driver, wait).sendKeys(pass);
		PageFactoryDefinition.password.sendKeys(pass);
		System.out.println(pass);
		
		try {
			Properties properties = new Properties();
			FileOutputStream file = new FileOutputStream(System.getProperty("user.dir") +"/src/com/selenium/config/user.properties");
			
			properties.setProperty("username", mail);
			properties.setProperty("password", pass);
			System.out.println("password written in file"+pass);
			properties.store(file, "Login credentials");
			file.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//Registration.phone(driver, wait).sendKeys(phone);
		PageFactoryDefinition.phone.sendKeys(phone);
		//Registration.address1(driver, wait).sendKeys(addr1);
		PageFactoryDefinition.address1.sendKeys(addr1);
		//Registration.address2(driver, wait).sendKeys(addr2);
		PageFactoryDefinition.address2.sendKeys(addr2);
		//Registration.city(driver, wait).sendKeys(city);
		PageFactoryDefinition.city.sendKeys(city);

		Select drop = new Select(page.state);
		drop.selectByVisibleText(state);

		//element = Registration.post(driver, wait);
		//element.sendKeys(post);
		PageFactoryDefinition.post.sendKeys(post);
		//Registration.home(driver, wait).sendKeys(home);
		PageFactoryDefinition.home.sendKeys(home);
		//Registration.submit(driver, wait).click();
		PageFactoryDefinition.submit.click();
	}

	public static void userLogin(String user, String pass) {
		Cart.user(driver, wait).sendKeys(user);
		Cart.pass(driver, wait).sendKeys(pass);
		Cart.login(driver).click();

	}

	public static void searchBeforeCart(String data) {
		Search.search(driver, wait).sendKeys(data);
		/*Assert.assertEquals(Search.search(driver,
		 wait).getAttribute("value"), data);*/
		Search.submit(driver, wait).click();

	}

	public static void add() {
		Cart.addToCart(driver, wait).click();
		System.out.println("cart");
	}

	public static void check() {
		Cart.checkout(driver, wait).click();
	}

}