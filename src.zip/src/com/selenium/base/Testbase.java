package com.selenium.base;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.pof.PageFactoryDefinition;
import com.selenium.util.Xls_Reader;

public class Testbase {
public static WebDriver driver=null;
public static WebDriverWait wait=null;
public static Xls_Reader suiteAxls=null;
public static boolean isInitalized=false;
public static WebElement element;
public static String browser;

public static PageFactoryDefinition page=PageFactory.initElements(driver,PageFactoryDefinition.class);
public void initialize()
{
 
  if(!isInitalized){
suiteAxls = new Xls_Reader(System.getProperty("user.dir")+"\\src\\com\\selenium\\testdata\\TestData.xlsx");
isInitalized=true;
}
}
}
