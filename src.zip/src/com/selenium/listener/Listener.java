package com.selenium.listener;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

public class Listener implements ISuiteListener,ITestListener,IInvokedMethodListener{

	@Override
	public void onStart(ISuite suite) {
		System.out.println("This will be executed before suite,this is ISuiteListener onStart method");
		
	}

	@Override
	public void onFinish(ISuite suite) {
		System.out.println("This will be executed after suite,this is ISuiteListener onFinish method");
		
	}

	@Override
	public void onTestStart(ITestResult result) {
	System.out.println("Test is started");
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Test succeeded"+result.getName());
		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Test failed"+result.getName());
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println("Test is skipped"+result.getName());
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		System.out.println("Test is on success percentage"+result.getName());
		
	}

	@Override
	public void onStart(ITestContext context)
	{
		System.out.println("This is executed before the test is started,This is the ITestListener onstart method");
	}

	@Override
	public void onFinish(ITestContext context) {
		System.out.println("This is executed after the test is executed,This is the ITestListener onFinish method");
		
	}

	
	public void beforeInvocation(IInvokedMethod method , ITestResult testResult) {
		String demo="This will be invoked before all methods including @before,@after,@Test"+ method.getTestMethod()+""+testResult.getName();
		Reporter.log(demo, true);
		
	}

	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
		System.out.println("This will be invoked after all methods including @before,@after,@Test"+testResult.getName());
		
	}

}
