package com.selenium.pof;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.selenium.base.Testbase;

public class PageFactoryDefinition extends Testbase {
	
	
	@FindBy(how = How.NAME, using ="button")
	public static WebElement agree;
	
	@FindBy(how = How.CLASS_NAME, using ="login")
	public static WebElement login ;
	
	@FindBy(how = How.ID, using ="email_create")
	public static WebElement email;
	
	@FindBy(how = How.ID, using ="SubmitCreate")
	public static WebElement create;
	
	@FindBy(how = How.NAME, using ="customer_firstname")
	public static WebElement first;
	
	@FindBy(how = How.NAME, using ="customer_lastname")
	public static WebElement last;
	
	@FindBy(how = How.ID, using ="passwd ")
	public static WebElement password;
	
	@FindBy(how = How.NAME, using ="address1")
	public static WebElement address1;
	
	@FindBy(how = How.NAME, using ="address2")
	public static WebElement address2;
	
	@FindBy(how = How.NAME, using ="city")
	public static WebElement city;
	
	@FindBy(how = How.ID, using ="id_state")
	public static WebElement state;
	
	@FindBy(how = How.NAME, using ="postcode")
	public static WebElement post;
	
	@FindBy(how = How.NAME, using ="phone")
	public static WebElement phone;
	
	@FindBy(how = How.NAME, using ="company")
	public static WebElement company;
	
	@FindBy(how = How.NAME, using ="phone_mobile")
	public static WebElement home;
	
	@FindBy(how = How.NAME, using ="submitAccount")
	public static WebElement submit;

}
