package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;

public class Cart extends Testbase{

	public static WebElement user(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
		driver.findElement(By.id("email"));
		return element;
	}
	public static WebElement pass(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("passwd")));
		driver.findElement(By.id("passwd"));
		return element;
	}
	public static WebElement login(WebDriver driver)
	{
		
		driver.findElement(By.id("SubmitLogin"));
		
		return element;
	}
	
	public static WebElement addToCart(WebDriver driver,WebDriverWait wait)
	{
		/*element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='button ajax_add_to_cart_button btn btn-default']/span[1]")));
		driver.findElement(By.xpath("//a[@class='button ajax_add_to_cart_button btn btn-default']/span[1]"));*/
		/*element=wait.until(ExpectedConditions.elementToBeClickable(By.tagName("a")));
		driver.findElement(By.tagName("a"));*/
		element=wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Add to cart")));
		
		Actions action = new Actions(driver);
		 action.moveToElement(element).moveToElement(driver.findElement(By.linkText("Add to cart"))).build().perform();
		System.out.println(element);
		return element;
	}
	public static WebElement checkout(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='btn btn-default button button-medium']/span")));
		driver.findElement(By.xpath("//a[@class='btn btn-default button button-medium']/span"));
		return element;
	}
	
}
