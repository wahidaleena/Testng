package com.selenium.pom;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;

public class IAgree extends Testbase {

	public static WebElement agree(WebDriver driver,WebDriverWait wait)
	{
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.name("button")));
		return element;
		//WebElement but=driver.findElement(By.name("button"));
		//return but;
		
	}
}
