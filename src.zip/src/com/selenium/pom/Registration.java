package com.selenium.pom;

//import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;

public class Registration extends Testbase {
	public static WebElement first(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("customer_firstname")));
		//driver.findElement(By.name("customer_firstname"));
		return element;
	}
	public static WebElement second(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("customer_lastname")));
		driver.findElement(By.name("customer_lastname"));
		return element;
	}
	public static WebElement password(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("passwd")));
		driver.findElement(By.id("passwd"));
		return element;
	}
	public static WebElement address1(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("address1")));
		driver.findElement(By.name("address1"));
		return element;
	}
	public static WebElement address2(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("address2")));
		driver.findElement(By.name("address2"));
		return element;
	}
	public static WebElement city(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("city")));
		driver.findElement(By.name("city"));
		return element;
	}
	public static WebElement state(WebDriver driver,WebDriverWait wait)
	{
		//element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("id_state")));
		
		element=driver.findElement(By.id("id_state"));
        return element;
	}
	
	public static WebElement post(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("postcode")));
		
		driver.findElement(By.name("postcode"));
		return element;
	}
	public static WebElement home(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("phone")));
		driver.findElement(By.name("phone"));
		return element;
	}
	public static WebElement company(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("company")));
		driver.findElement(By.name("company"));
		return element;
	}
	public static WebElement phone(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("phone_mobile")));
		driver.findElement(By.name("phone_mobile"));
		return element;
	}
	public static WebElement submit(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("submitAccount")));
		driver.findElement(By.name("submitAccount"));
		return element;
	}
	
	
	
	

}
