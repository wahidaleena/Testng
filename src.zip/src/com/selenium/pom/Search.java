package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;

public class Search extends Testbase {
	public static WebElement search(WebDriver driver,WebDriverWait wait)
	{
		WebElement element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("search_query_top")));
	//WebElement but=driver.findElement(By.id("search_query_top"));
		return element;
		
		
	}
	public static WebElement submit(WebDriver driver,WebDriverWait wait)
	{
		WebElement element=wait.until(ExpectedConditions.elementToBeClickable(By.name("submit_search")));
		//WebElement but=driver.findElement(By.name("submit_search"));
		return element;
		
		
	}
	

}
