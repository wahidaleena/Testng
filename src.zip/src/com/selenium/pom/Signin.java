package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Signin {
	
public static WebElement signin(WebDriver driver,WebDriverWait wait)
{
	WebElement element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("login")));
	driver.findElement(By.className("login"));
	return element;
		
}

}
