package com.selenium.pom;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;

public class Username extends Testbase {

	public static WebElement signin(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email_create")));
		driver.findElement(By.id("email_create"));
		

		return element;
	}
	public static WebElement create(WebDriver driver,WebDriverWait wait)
	{
		element=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("SubmitCreate")));
		driver.findElement(By.id("SubmitCreate")).click();
		return element;
	}
	
}
