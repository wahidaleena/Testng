package com.selenium.script;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.Functions.*;
import com.selenium.base.Testbase;
import com.selenium.pom.IAgree;
import com.selenium.pom.Search;
import com.selenium.retry.Retry;

import com.selenium.util.TestUtil;
/*
 * Author:Aleena wahid
 */

	

public class RegisterUsers extends Testbase {
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=false;
	static int count=-1;
	static String url;
	
	@BeforeTest()
	@Parameters({"url","browser"})
	public void checkTest(String url,String browser){
		initialize();
		if(!TestUtil.isTestCaseRunnable(suiteAxls,this.getClass().getSimpleName())){
			
			
			throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
		}
		this.url=url;
		Testbase.browser=browser;
	}
	
	@Test(dataProvider="GetUser")
	public void registerUser(String email,String pass,String fname,String lname,String cpmny,String addr1,String addr2,String city,String state,String post,String home,String phone)throws IOException
	{
		
			try {
				GenericFunctionlib.openBrowser(url);
				System.out.println("Reg has 3rd priority");
				System.out.println("username is:"+email);
				System.out.println("password is"+pass);
				System.out.println("first name is"+fname);
				LegacyFunctions.sign();
				LegacyFunctions.reg(email, pass, fname, lname, cpmny, addr1, addr2,city,state, post, home, phone);
			} catch (Exception e) {
				
				System.out.println(e);
			}
		
		
	}
	/*
	 * Add item to the cart by using the username and password from the registrationpage
	 * It is written to an OR
	 */
	@Test(dependsOnMethods={"registerUser"})
	public static void cart()throws Exception
	{
		
		Properties prop = new Properties();
		FileInputStream details = new FileInputStream(
		System.getProperty("user.dir") + "/src/com/selenium/config/user.properties");
		prop.load(details);
		String myuser = prop.getProperty("username");
		System.out.println( myuser);
		String myPass=prop.getProperty("password");
		System.out.println(myPass);
		GenericFunctionlib.openBrowser(url);
		LegacyFunctions.sign();
		LegacyFunctions.userLogin(myuser, myPass);
		Properties props = new Properties();
		FileInputStream pro = new FileInputStream(
		System.getProperty("user.dir") + "/src/com/selenium/config/product.properties");
		props.load(pro);
		String myPro = props.getProperty("product");
		System.out.println(myPro);
		LegacyFunctions.searchBeforeCart(myPro);
		System.out.println("check");
		LegacyFunctions.add();
		LegacyFunctions.check();
		GenericFunctionlib.closeBrowser();
	}
	
	/*  ExpectedException ,the test pass without exception
	   */
	 
	@Test(expectedExceptions = ArithmeticException.class)
	public static void divisionWithException() {
		int i = 1 / 0;
	}
	
	@DataProvider	
	public Object[][] GetUser(){
		System.out.println("dataprovider class "+this.getClass().getSimpleName());
		return TestUtil.getData(suiteAxls, this.getClass().getSimpleName()) ;

	}
	@AfterTest
	public void reportTestResult(){
		if(isTestPass)
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "PASS");
		else
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "FAIL");

	}

	@AfterMethod
	public void reportDataSetResult(){
		if(skip)
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "SKIP");
		else if(fail){
			isTestPass=false;
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "FAIL");
		}
		else
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "PASS");
		
		skip=false;
		fail=false;
		driver.quit();

	}
}
