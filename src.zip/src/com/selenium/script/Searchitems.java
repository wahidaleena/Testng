package com.selenium.script;

import java.io.IOException;

import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import com.selenium.Functions.GenericFunctionlib;
import com.selenium.Functions.LegacyFunctions;
import com.selenium.base.Testbase;
import com.selenium.util.TestUtil;
/*
 * Author:Aleena Wahid
 */

//@Listeners(com.selenium.listener.Listener.class)
public class Searchitems extends Testbase {
	
	 static boolean fail=false;
	 static boolean skip=false;
     static boolean isTestPass=false;
     static int count=-1;
	static String url;
	/*private static ExtentReports reports;*/
	
	
	@BeforeTest
	@Parameters({"url","browser"})
	
	public void checkTest(String url,String browser){
		initialize();
		if(!TestUtil.isTestCaseRunnable(suiteAxls,this.getClass().getSimpleName())){
			System.out.println("entering into exception");
			throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
		}
		System.out.println("not entering into exception");
		this.url=url;
		System.out.println(url);
		Testbase.browser=browser;
	}
	
	@Test(dataProvider="dataForSearch")
	public static void searchitemsFunc(String data) throws IOException
	{
		//Initiate Extent Reports
		/* reports=new ExtentReports("D:\\workspace\\TestNG\\Reports\\results.html",true);
		 */
		//Declare Start test name
		// ExtentTest test = reports.startTest("Verify Search page"); 
		 
		GenericFunctionlib.openBrowser(url);
		System.out.println("search items has 1st priority");
		LegacyFunctions.searchItem(data);
		isTestPass=true;
		//Ending the Test
		//reports.endTest(test); 
		//writing everything to document
		//reports.flush();
        GenericFunctionlib.closeBrowser();
		
		
	}
	/*@Test(priority=1)
	public static void demo()
	{
		System.out.println("This has 2nd priority");
	}
	@Test(enabled=false)
	public static void check()
	{
		System.out.println("Hi");
	}*/
@DataProvider
public  Object[][] dataForSearch()
{
	System.out.println("dataprovider class "+this.getClass().getSimpleName());
	return TestUtil.getData(suiteAxls, this.getClass().getSimpleName());
	
}

@AfterTest
public void reportTestResult(){
	if(isTestPass)
		TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "PASS");
	else
		TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "FAIL");

}

@AfterMethod
public void reportDataSetResult(){
	if(skip)
		TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "SKIP");
	else if(fail){
		isTestPass=false;
		TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "FAIL");
	}
	else
		TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "PASS");
	
	skip=false;
	fail=false;
	driver.quit();
	
}
}
