package com.selenium.script;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.selenium.base.Testbase;


public class Table extends Testbase 

{	
	private int rowCount=0;
	@Test
	public void check() throws InterruptedException
	{
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\u60903\\Downloads\\chromedriver_win32\\chromedriver.exe");
	driver=new ChromeDriver();

	driver.get("http://toolsqa.com/automation-practice-table/");
	driver.findElement(By.name("button")).click();
	//Thread.sleep(3000);
	
	//driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[1]/td[6]/a")).click();
	//ArrayList<String>list=new ArrayList<String>();
	//List head=(List) driver.findElement(By.tagName("th"));
	
	List<WebElement> test=driver.findElement(By.xpath("//*[@id='content']/table/tbody")).findElements(By.tagName("tr"));
	
	for(WebElement w:test)
	{
		List<WebElement> cells=null;
		//List<WebElement> cells=w.get(rowCount).findElements(By.tagName("td"));
		//System.out.println(w.getText().toString());
		List<WebElement> head=w.findElements(By.tagName("th"));
		for (WebElement webElement : head) {
			System.out.println(webElement.getText().toString());
		}
		cells=w.findElements(By.tagName("td"));
		for (WebElement webElement : cells) {
			System.out.println(webElement.getText().toString());
		}
		
	}
	}
	
	
	
	/*List<WebElement> rows=driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[1]/th")).findElements(By.tagName("tr"));
	System.out.println(rows.size());
	for(WebElement s:rows)
	{
	
	System.out.println(s);
	}
	Thread.sleep(3000);
	List<WebElement> cells=rows.get(rowCount).findElements(By.tagName("td"));
	for(int count=0;count<=cells.size();count++)
	{
		String cellsval=cells.get(count).getText();
		System.out.println("cell data"+cellsval);
	}*/
	
	/*driver.get("http://bigcharts.marketwatch.com/");
	Thread.sleep(3000);
	driver.findElement(By.xpath("//*[@id='qchartform']/button[1]")).click();*/
	
	@Test
	public  void getGraphValues() throws InterruptedException
	{
		
	driver.get("https://yuilibrary.com/yui/docs/charts/charts-pie.html");
	Thread.sleep(3000);
	WebElement check=driver.findElement(By.xpath("//*[contains(@class,'yui3-shape yui3-svgShape yui3-svgPieSlice yui3-svgSvgPieSlice yui3-seriesmarker')][@fill='#e8cdb7']"));
	Thread.sleep(3000);
	
	List<WebElement> tool=driver.findElements(By.xpath("//div[contains(@id,'_tooltip')]"));
	check.click();
	//System.out.println("Tooltip value"+tool.getText());
	for (WebElement webElement : tool) {
		
	System.out.println("Tooltip values for piechart are:\n"+webElement.getText()+"\t");
	}
	driver.quit();
	
	
	
	}
	@Test
	public void dbasicGraph() throws InterruptedException
	{
		driver.get("http://yuilibrary.com/yui/docs/charts/charts-simple.html");
		WebElement check1=driver.findElement(By.xpath("//*[contains(@class,'yui3-shape yui3-svgShape yui3-circle yui3-svgCircle yui3-seriesmarker')][@fill='#6084d0']"));
		Thread.sleep(3000);
		List<WebElement> tools=driver.findElements(By.xpath("//*[contains(@class,'yui3-chart-tooltip')]"));
		check1.click();
		for (WebElement webElement : tools) {
			
			System.out.println("Tooltip values for basic graph are:\n"+webElement.getText()+"\t");
			}
		
	}
}



